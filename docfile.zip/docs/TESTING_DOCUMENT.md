# Dokumen Pengujian Black Box Testing

## Sistem Informasi Manajemen Toko Kue (Pawon3D)

Dalam tabel pengujian di bawah ini, terdapat berbagai aktivitas pengujian yang mewakili fungsi atau fitur sistem yang ingin diuji, seperti proses *login*, pengisian data, hingga pencetakan data. Setiap fitur memiliki harapan pengguna yang menjadi acuan pengujian. Hasil pengujian meliputi *output* yang dihasilkan sistem, serta kesimpulan yang diambil untuk menentukan apakah fitur tersebut sudah sesuai dengan ekspektasi. Apabila ditemukan fitur yang tidak berfungsi sebagaimana mestinya, maka perbaikan akan dilakukan pada iterasi atau *increment* berikutnya.

---

## 1. Pengujian Aktor: PEMILIK

Pemilik memiliki akses penuh ke seluruh modul sistem termasuk manajemen pekerja, peran, pelanggan, profil usaha, dan laporan.

### 1.1 Autentikasi

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-OWN-001 | Login sebagai Pemilik dengan kredensial valid | Sistem menampilkan dashboard dengan akses ke semua modul | | [ ] gagal / [ ] berhasil |
| TC-OWN-002 | Logout dari sistem | Sistem menghapus sesi dan redirect ke halaman login | | [ ] gagal / [ ] berhasil |

### 1.2 Kelola Pekerja

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-OWN-003 | Melihat daftar pekerja | Sistem menampilkan list users dengan role dan status | | [ ] gagal / [ ] berhasil |
| TC-OWN-004 | Menambah pekerja baru dengan data valid | Sistem menyimpan user dengan is_active = false | | [ ] gagal / [ ] berhasil |
| TC-OWN-005 | Mengirim undangan aktivasi ke pekerja baru | Sistem generate invitation_token dan kirim email | | [ ] gagal / [ ] berhasil |
| TC-OWN-006 | Menambah pekerja dengan email yang sudah terdaftar | Sistem menampilkan pesan error "Email sudah digunakan" | | [ ] gagal / [ ] berhasil |
| TC-OWN-007 | Edit data pekerja | Sistem memperbarui data pekerja | | [ ] gagal / [ ] berhasil |
| TC-OWN-008 | Mengaktifkan pekerja yang nonaktif | Sistem mengupdate is_active = true | | [ ] gagal / [ ] berhasil |
| TC-OWN-009 | Menonaktifkan pekerja | Sistem mengupdate is_active = false | | [ ] gagal / [ ] berhasil |
| TC-OWN-010 | Cetak daftar pekerja PDF | Sistem menghasilkan file PDF | | [ ] gagal / [ ] berhasil |

### 1.3 Kelola Peran & Hak Akses

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-OWN-011 | Melihat daftar peran | Sistem menampilkan list roles dengan permissions | | [ ] gagal / [ ] berhasil |
| TC-OWN-012 | Assign role ke pekerja | Sistem menyimpan model_has_roles | | [ ] gagal / [ ] berhasil |
| TC-OWN-013 | Edit permission role | Sistem memperbarui role_has_permissions | | [ ] gagal / [ ] berhasil |
| TC-OWN-014 | Cetak daftar peran PDF | Sistem menghasilkan file PDF | | [ ] gagal / [ ] berhasil |

### 1.4 Kelola Pelanggan & Poin

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-OWN-015 | Melihat daftar pelanggan | Sistem menampilkan list customers dengan poin | | [ ] gagal / [ ] berhasil |
| TC-OWN-016 | Melihat detail pelanggan | Sistem menampilkan data pelanggan dan riwayat transaksi | | [ ] gagal / [ ] berhasil |
| TC-OWN-017 | Melihat riwayat poin pelanggan | Sistem menampilkan points_histories (earn/redeem) | | [ ] gagal / [ ] berhasil |

### 1.5 Kelola Profil Usaha

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-OWN-018 | Edit profil usaha (nama, alamat, kontak) | Sistem menyimpan data store_profiles | | [ ] gagal / [ ] berhasil |
| TC-OWN-019 | Upload logo usaha | Sistem menyimpan logo pada store_profiles | | [ ] gagal / [ ] berhasil |
| TC-OWN-020 | Menambah dokumen usaha | Sistem menyimpan store_documents | | [ ] gagal / [ ] berhasil |

### 1.6 Kelola Channel Pembayaran

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-OWN-021 | Menambah payment channel Bank | Sistem menyimpan payment_channel dengan type "Bank" | | [ ] gagal / [ ] berhasil |
| TC-OWN-022 | Menambah payment channel QRIS | Sistem menyimpan payment_channel dengan qris_image | | [ ] gagal / [ ] berhasil |
| TC-OWN-023 | Edit payment channel | Sistem memperbarui data payment_channel | | [ ] gagal / [ ] berhasil |
| TC-OWN-024 | Menonaktifkan payment channel | Sistem mengupdate is_active = false | | [ ] gagal / [ ] berhasil |

### 1.7 Laporan

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-OWN-025 | Melihat laporan kasir | Sistem menampilkan ringkasan penjualan per shift | | [ ] gagal / [ ] berhasil |
| TC-OWN-026 | Melihat laporan produksi | Sistem menampilkan ringkasan produksi | | [ ] gagal / [ ] berhasil |
| TC-OWN-027 | Melihat laporan inventori | Sistem menampilkan ringkasan stok dan pergerakan | | [ ] gagal / [ ] berhasil |
| TC-OWN-028 | Export laporan ke PDF/Excel | Sistem menghasilkan file yang dapat diunduh | | [ ] gagal / [ ] berhasil |

### 1.8 Notifikasi

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-OWN-029 | Melihat daftar notifikasi | Sistem menampilkan list notifications | | [ ] gagal / [ ] berhasil |
| TC-OWN-030 | Menandai notifikasi sebagai dibaca | Sistem mengupdate is_read = true | | [ ] gagal / [ ] berhasil |

---

## 2. Pengujian Aktor: KASIR

Kasir memiliki akses ke modul POS, transaksi, shift, dan laporan kasir.

### 2.1 Autentikasi

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-CSH-001 | Login sebagai Kasir dengan kredensial valid | Sistem menampilkan dashboard kasir | | [ ] gagal / [ ] berhasil |
| TC-CSH-002 | Aktivasi akun kasir baru dengan token valid | Sistem mengaktifkan akun dan redirect ke dashboard | | [ ] gagal / [ ] berhasil |
| TC-CSH-003 | Logout dari sistem | Sistem menghapus sesi dan redirect ke login | | [ ] gagal / [ ] berhasil |

### 2.2 Shift Kasir

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-CSH-004 | Membuka sesi kasir dengan input kas awal | Sistem menyimpan shift dengan status "Buka" | | [ ] gagal / [ ] berhasil |
| TC-CSH-005 | Melakukan transaksi saat shift aktif | Transaksi terhubung dengan created_by_shift | | [ ] gagal / [ ] berhasil |
| TC-CSH-006 | Menutup sesi kasir dengan input kas akhir | Sistem mengupdate status "Tutup" dan hitung selisih | | [ ] gagal / [ ] berhasil |
| TC-CSH-007 | Melihat ringkasan shift | Sistem menampilkan total sales, refunds, selisih kas | | [ ] gagal / [ ] berhasil |

### 2.3 Transaksi Siap Beli

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-CSH-008 | Membuka halaman POS siap beli | Sistem menampilkan produk is_ready = true | | [ ] gagal / [ ] berhasil |
| TC-CSH-009 | Menambahkan produk ke keranjang | Sistem menghitung subtotal otomatis | | [ ] gagal / [ ] berhasil |
| TC-CSH-010 | Mengubah quantity produk | Sistem memperbarui subtotal | | [ ] gagal / [ ] berhasil |
| TC-CSH-011 | Menghapus produk dari keranjang | Sistem memperbarui total | | [ ] gagal / [ ] berhasil |
| TC-CSH-012 | Input pelanggan dengan nomor telepon baru | Sistem membuat customer baru (firstOrCreate) | | [ ] gagal / [ ] berhasil |
| TC-CSH-013 | Pembayaran tunai dengan nominal cukup | Sistem menyimpan transaksi dan hitung kembalian | | [ ] gagal / [ ] berhasil |
| TC-CSH-014 | Pembayaran non-tunai dengan channel | Sistem menyimpan payment dengan channel_id | | [ ] gagal / [ ] berhasil |
| TC-CSH-015 | Stok produk berkurang setelah transaksi | Sistem decrement stock sesuai quantity | | [ ] gagal / [ ] berhasil |
| TC-CSH-016 | Poin pelanggan bertambah setelah transaksi lunas | Sistem menambah poin = floor(total/10000) | | [ ] gagal / [ ] berhasil |
| TC-CSH-017 | Cetak struk transaksi | Sistem menghasilkan struk PDF | | [ ] gagal / [ ] berhasil |

### 2.4 Transaksi Pesanan

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-CSH-018 | Membuat pesanan reguler dengan DP | Status "Antrian", payment_status "DP" | | [ ] gagal / [ ] berhasil |
| TC-CSH-019 | Membuat pesanan reguler lunas | Status "Antrian", payment_status "Lunas" | | [ ] gagal / [ ] berhasil |
| TC-CSH-020 | Input jadwal ambil pesanan | Sistem menyimpan start_date/end_date | | [ ] gagal / [ ] berhasil |
| TC-CSH-021 | Produksi otomatis dibuat setelah pesanan | Sistem membuat production terkait | | [ ] gagal / [ ] berhasil |
| TC-CSH-022 | Pelunasan pesanan yang sudah DP | Sistem update payment_status = "Lunas" | | [ ] gagal / [ ] berhasil |
| TC-CSH-023 | Melihat daftar pesanan | Sistem menampilkan transaksi method pesanan | | [ ] gagal / [ ] berhasil |

### 2.5 Refund

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-CSH-024 | Membatalkan transaksi dengan refund tunai | Sistem membuat refund, status "Dibatalkan" | | [ ] gagal / [ ] berhasil |
| TC-CSH-025 | Refund transfer dengan payment channel | Sistem menyimpan channel dan account_number | | [ ] gagal / [ ] berhasil |
| TC-CSH-026 | Upload bukti refund | Sistem menyimpan proof_image | | [ ] gagal / [ ] berhasil |
| TC-CSH-027 | Refund tercatat di shift aktif | Refund terhubung dengan refund_by_shift | | [ ] gagal / [ ] berhasil |

### 2.6 Laporan Kasir

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-CSH-028 | Melihat laporan transaksi | Sistem menampilkan list transaksi | | [ ] gagal / [ ] berhasil |
| TC-CSH-029 | Filter laporan berdasarkan tanggal | Sistem menampilkan data sesuai filter | | [ ] gagal / [ ] berhasil |
| TC-CSH-030 | Export laporan transaksi PDF | Sistem menghasilkan file PDF | | [ ] gagal / [ ] berhasil |

---

## 3. Pengujian Aktor: PRODUKSI

Produksi memiliki akses ke modul antrian produksi, proses produksi, dan laporan produksi.

### 3.1 Autentikasi

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-PRD-001 | Login sebagai Produksi dengan kredensial valid | Sistem menampilkan dashboard produksi | | [ ] gagal / [ ] berhasil |
| TC-PRD-002 | Aktivasi akun produksi baru dengan token valid | Sistem mengaktifkan akun dan redirect ke dashboard | | [ ] gagal / [ ] berhasil |
| TC-PRD-003 | Logout dari sistem | Sistem menghapus sesi dan redirect ke login | | [ ] gagal / [ ] berhasil |

### 3.2 Antrian Produksi

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-PRD-004 | Melihat antrian produksi | Sistem menampilkan produksi status "Antrian" | | [ ] gagal / [ ] berhasil |
| TC-PRD-005 | Filter antrian berdasarkan method | Sistem menampilkan sesuai filter | | [ ] gagal / [ ] berhasil |
| TC-PRD-006 | Melihat detail produksi | Sistem menampilkan detail + komposisi bahan | | [ ] gagal / [ ] berhasil |

### 3.3 Proses Produksi

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-PRD-007 | Cek stok bahan sebelum mulai | Sistem menampilkan ketersediaan bahan | | [ ] gagal / [ ] berhasil |
| TC-PRD-008 | Memulai produksi dengan stok cukup | Status "Proses", stok bahan berkurang (FIFO) | | [ ] gagal / [ ] berhasil |
| TC-PRD-009 | Memulai produksi dengan stok kurang | Sistem menampilkan error "Stok tidak cukup" | | [ ] gagal / [ ] berhasil |
| TC-PRD-010 | Menugaskan pekerja ke produksi | Sistem menyimpan production_workers | | [ ] gagal / [ ] berhasil |
| TC-PRD-011 | Input hasil produksi (qty jadi) | Sistem menyimpan quantity_get | | [ ] gagal / [ ] berhasil |
| TC-PRD-012 | Input hasil produksi (qty gagal) | Sistem menyimpan quantity_fail | | [ ] gagal / [ ] berhasil |
| TC-PRD-013 | Menyelesaikan produksi | Status "Selesai", stok produk bertambah | | [ ] gagal / [ ] berhasil |
| TC-PRD-014 | Produksi pesanan update transaksi | Status transaksi menjadi "Dapat Diambil" | | [ ] gagal / [ ] berhasil |
| TC-PRD-015 | Notifikasi terkirim saat produksi selesai | Sistem membuat notification | | [ ] gagal / [ ] berhasil |

### 3.4 Produksi Siap Beli (Manual)

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-PRD-016 | Membuat produksi siap beli manual | Sistem menyimpan produksi method "siap-beli" | | [ ] gagal / [ ] berhasil |
| TC-PRD-017 | Menambah detail produk untuk produksi | Sistem menyimpan production_details | | [ ] gagal / [ ] berhasil |

### 3.5 Laporan Produksi

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-PRD-018 | Melihat riwayat produksi | Sistem menampilkan list produksi selesai | | [ ] gagal / [ ] berhasil |
| TC-PRD-019 | Cetak laporan produksi PDF | Sistem menghasilkan file PDF | | [ ] gagal / [ ] berhasil |
| TC-PRD-020 | Cetak detail produksi PDF | Sistem menghasilkan file PDF detail | | [ ] gagal / [ ] berhasil |

---

## 4. Pengujian Aktor: INVENTORI

Inventori memiliki akses ke modul produk, bahan baku, belanja, hitung stok, dan laporan inventori.

### 4.1 Autentikasi

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-INV-001 | Login sebagai Inventori dengan kredensial valid | Sistem menampilkan dashboard inventori | | [ ] gagal / [ ] berhasil |
| TC-INV-002 | Aktivasi akun inventori baru dengan token valid | Sistem mengaktifkan akun dan redirect ke dashboard | | [ ] gagal / [ ] berhasil |
| TC-INV-003 | Logout dari sistem | Sistem menghapus sesi dan redirect ke login | | [ ] gagal / [ ] berhasil |

### 4.2 Kelola Produk

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-INV-004 | Melihat daftar produk | Sistem menampilkan list products | | [ ] gagal / [ ] berhasil |
| TC-INV-005 | Menambah produk baru dengan data valid | Sistem menyimpan product | | [ ] gagal / [ ] berhasil |
| TC-INV-006 | Menambah produk dengan kategori | Sistem menyimpan product_categories | | [ ] gagal / [ ] berhasil |
| TC-INV-007 | Upload gambar produk valid (<2MB) | Sistem menyimpan product_image | | [ ] gagal / [ ] berhasil |
| TC-INV-008 | Upload gambar produk invalid (>2MB) | Sistem menampilkan error validasi | | [ ] gagal / [ ] berhasil |
| TC-INV-009 | Mengatur komposisi bahan produk | Sistem menyimpan product_compositions | | [ ] gagal / [ ] berhasil |
| TC-INV-010 | Menambah biaya lain produk | Sistem menyimpan other_costs | | [ ] gagal / [ ] berhasil |
| TC-INV-011 | Hitung modal produk otomatis | Sistem menghitung capital | | [ ] gagal / [ ] berhasil |
| TC-INV-012 | Edit produk | Sistem memperbarui data product | | [ ] gagal / [ ] berhasil |
| TC-INV-013 | Aktifkan/Nonaktifkan produk | Sistem update is_active | | [ ] gagal / [ ] berhasil |

### 4.3 Kelola Kategori & Satuan

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-INV-014 | Menambah kategori produk | Sistem menyimpan category | | [ ] gagal / [ ] berhasil |
| TC-INV-015 | Menambah kategori bahan | Sistem menyimpan ingredient_category | | [ ] gagal / [ ] berhasil |
| TC-INV-016 | Menambah satuan dengan konversi | Sistem menyimpan unit dengan base_unit_id | | [ ] gagal / [ ] berhasil |
| TC-INV-017 | Menambah jenis biaya | Sistem menyimpan type_cost | | [ ] gagal / [ ] berhasil |

### 4.4 Kelola Bahan Baku

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-INV-018 | Melihat daftar bahan baku | Sistem menampilkan list materials | | [ ] gagal / [ ] berhasil |
| TC-INV-019 | Menambah bahan baku baru | Sistem menyimpan material | | [ ] gagal / [ ] berhasil |
| TC-INV-020 | Mengatur minimum stock | Sistem menyimpan minimum | | [ ] gagal / [ ] berhasil |
| TC-INV-021 | Melihat batch per material (FIFO) | Sistem menampilkan batches sorted by date | | [ ] gagal / [ ] berhasil |
| TC-INV-022 | Konversi satuan antar unit | Sistem menghitung quantity dalam target unit | | [ ] gagal / [ ] berhasil |

### 4.5 Kelola Supplier

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-INV-023 | Menambah supplier baru | Sistem menyimpan supplier | | [ ] gagal / [ ] berhasil |
| TC-INV-024 | Edit supplier | Sistem memperbarui data supplier | | [ ] gagal / [ ] berhasil |

### 4.6 Belanja Bahan Baku

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-INV-025 | Membuat rencana belanja | Sistem menyimpan expense status "Rencana" | | [ ] gagal / [ ] berhasil |
| TC-INV-026 | Menambah item belanja | Sistem menyimpan expense_details | | [ ] gagal / [ ] berhasil |
| TC-INV-027 | Memulai belanja | Status "Proses", is_start = true | | [ ] gagal / [ ] berhasil |
| TC-INV-028 | Input hasil aktual (qty, harga, expiry) | Sistem menyimpan quantity_get, price_get | | [ ] gagal / [ ] berhasil |
| TC-INV-029 | Menyelesaikan belanja | Batch terbuat, inventory_log (in), status "Selesai" | | [ ] gagal / [ ] berhasil |
| TC-INV-030 | Stok material bertambah setelah belanja | Total batch quantity bertambah | | [ ] gagal / [ ] berhasil |

### 4.7 Hitung Stok

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-INV-031 | Membuat rencana hitung stok | Sistem menyimpan hitung action "hitung" | | [ ] gagal / [ ] berhasil |
| TC-INV-032 | Membuat rencana untuk bahan rusak | Sistem menyimpan hitung action "rusak" | | [ ] gagal / [ ] berhasil |
| TC-INV-033 | Membuat rencana untuk bahan hilang | Sistem menyimpan hitung action "hilang" | | [ ] gagal / [ ] berhasil |
| TC-INV-034 | Memulai aksi hitung | Status "Proses", is_start = true | | [ ] gagal / [ ] berhasil |
| TC-INV-035 | Input qty aktual | Sistem menyimpan quantity_actual | | [ ] gagal / [ ] berhasil |
| TC-INV-036 | Menyelesaikan hitung - adjustment | Batch disesuaikan, inventory_log dibuat | | [ ] gagal / [ ] berhasil |
| TC-INV-037 | Menyelesaikan hitung - rusak/hilang | Batch berkurang, loss_total dihitung | | [ ] gagal / [ ] berhasil |

### 4.8 Alur Persediaan & Laporan

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-INV-038 | Melihat inventory log | Sistem menampilkan pergerakan stok | | [ ] gagal / [ ] berhasil |
| TC-INV-039 | Filter log berdasarkan material | Sistem menampilkan log material terpilih | | [ ] gagal / [ ] berhasil |
| TC-INV-040 | Melihat laporan inventori | Sistem menampilkan ringkasan stok | | [ ] gagal / [ ] berhasil |
| TC-INV-041 | Export laporan inventori PDF | Sistem menghasilkan file PDF | | [ ] gagal / [ ] berhasil |

### 4.9 Notifikasi

| Test Case ID | Deskripsi | Output yang Diharapkan | Output yang Didapatkan | Status |
|--------------|-----------|------------------------|------------------------|--------|
| TC-INV-042 | Notifikasi saat stok mencapai minimum | Sistem membuat notification alert | | [ ] gagal / [ ] berhasil |
| TC-INV-043 | Notifikasi saat batch mendekati expired | Sistem membuat notification alert | | [ ] gagal / [ ] berhasil |

---

## Ringkasan Test Cases per Aktor

| Aktor | Modul yang Diuji | Jumlah Test Case |
|-------|------------------|------------------|
| **Pemilik** | Autentikasi, Pekerja, Peran, Pelanggan, Profil Usaha, Payment Channel, Laporan, Notifikasi | 30 |
| **Kasir** | Autentikasi, Shift, Transaksi Siap Beli, Transaksi Pesanan, Refund, Laporan Kasir | 30 |
| **Produksi** | Autentikasi, Antrian, Proses Produksi, Produksi Manual, Laporan | 20 |
| **Inventori** | Autentikasi, Produk, Kategori, Bahan Baku, Supplier, Belanja, Hitung Stok, Laporan | 43 |
| **Total** | | **123** |

---

## Catatan Pengujian

- **Lingkungan**: Pengujian dilakukan pada environment local/staging
- **URL**: https://pawon3d.test
- **Browser**: Chrome/Edge versi terbaru
- **Data Uji**: Menggunakan seed data yang sudah disiapkan
- **Pelaksana**: [Nama Penguji]
- **Tanggal**: [Tanggal Pengujian]

---

## Kesimpulan

Berdasarkan hasil pengujian di atas:

| Aktor | Berhasil | Gagal | Persentase |
|-------|----------|-------|------------|
| Pemilik | ___ | ___ | ___% |
| Kasir | ___ | ___ | ___% |
| Produksi | ___ | ___ | ___% |
| Inventori | ___ | ___ | ___% |
| **Total** | ___ | ___ | ___% |

### Fitur yang Perlu Perbaikan:
1. ___
2. ___
3. ___

### Rekomendasi:
- ___
- ___
